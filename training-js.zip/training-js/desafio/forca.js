class Forca {

  constructor(word) {
    this.word = word;
    this.wordSubstitution = this.getWordPattern()
  }

  attempts = []; // array para savar as letras que foram tentadas
  life = 6; // Quantidade de vidas
  hits = 0; // quantidade de acertos



  verifyMatch(letra) { //metodo que verifica se a letra informada existe na palavra
    var secret = this.word;
    var search;
    var temporaryWord;

    search = secret.match(letra);

    if (search == null) {
      this.life--;
    }

    while (search != null) { // repetiçao que pesquisa a quantidade de incidências da letra na palavra
      temporaryWord = secret.search(letra);
      this.setLetraPalavra(letra, temporaryWord);
      //criar validacao para condicao de acerto
      this.hits++;
      secret = secret.replace(letra, 0);
      search = secret.match(letra); //forçar saida do while
    }
  }

  getWordPattern() {
    var wordToReturn = Array.from(this.word);
    for (let i = 0; i < wordToReturn.length; i++) {
      wordToReturn[i] = wordToReturn[i].replace(/[a-zA-z]/g, "_")
    }
    return wordToReturn;
  }

  setLetraPalavra(letra, indexes) {
    let wordSubstitution = this.wordSubstitution;
    for (let i = 0; i < wordSubstitution.length; i++) {
      if (i == indexes) {
        wordSubstitution[i] = wordSubstitution[i].replace("_", letra);
      }
    }
    return wordSubstitution;
  }


  chutar(letra) {
    if (this.attempts.includes(letra) || letra === '' || letra === ' ' || letra.length > 1) {
      console.log('Erro ao registrar a letra, verifique se foi digitada corretamente.')
    } else {
      this.attempts.push(letra);
      this.verifyMatch(letra);
      return this.attempts;
    }
  }

  buscarEstado() {
    var size = this.word.length;

    if (this.hits == size && this.life > 0) {
      return "ganhou"
    }
    if (this.life > 0 && this.hits <= size) {
      return "aguardando chute"
    } else {
      return "perdeu"
    }


  } // Possiveis valores: "perdeu", "aguardando chute" ou "ganhou"

  buscarDadosDoJogo() {
    return {
      letrasChutadas: this.attempts, // Deve conter todas as letras chutadas
      vidas: this.life, // Quantidade de vidas restantes
      palavra: this.wordSubstitution,// Deve ser um array com as letras que já foram acertadas ou o valor "" para as letras não identificadas (__)
      acertos: this.hits
    }
  }
}

module.exports = Forca;